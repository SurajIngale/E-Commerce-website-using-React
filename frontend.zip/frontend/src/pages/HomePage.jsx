
const HomePage = () => {
  return (
    <h1 className="text-center mt-5" style={{color:"red"}}>Welcome to Homepage</h1>
  )
}

export default HomePage